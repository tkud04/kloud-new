@include("admin.head")
@yield("content")
@include("admin.foot")
