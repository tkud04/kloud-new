	<!-- Banner section -->
	<section class="top-letest-product-section">
		<div class="container">
			<div>
			  <marquee>
				<img class="img img-fluid" src="{{asset('img/ad-img/ad-1.png')}}" alt="KloudTransact"/>
			  </marquee>
			</div>
		</div>
	</section>
	<!-- Banner section end  -->
