<center><h3>New Request From Client</h3></center>

<center>
<p><strong>Name: </strong>{{$name}}</p><br>
<p><strong>Email: </strong>{{$email}}</p><br>
<p><strong>Location: </strong>{{$location}}</p><br>
</center><br>

<p style="font-color: red;"><em><strong>Follow up on your clients and most importantly, GET PAID! Good luck</strong></em></p><br>