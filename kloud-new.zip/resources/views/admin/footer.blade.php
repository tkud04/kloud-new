      <footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="{{url('cobra-orders')}}">
                  Orders
                </a>
              </li>
              <li>
                <a href="{{url('cobra-users')}}">
                  Users
                </a>
              </li>
              <li>
                <a href="{{url('cobra-deals')}}">
                  Deals
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, powered with <i class="material-icons">favorite</i> by
            <a href="#" target="_blank">Disenado NG</a>.
          </div>
        </div>
      </footer>
    </div>
  </div>
