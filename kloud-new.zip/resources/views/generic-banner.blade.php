	<!-- Page info -->
	<div class="page-top-info wow rubberBand">
		<div class="container">
			<h4><?=$title?></h4>
			<div class="site-pagination">
				<a href="{{url('/')}}">Home</a> /
				<a href="#"><?=$title?></a> 
			</div>
		</div>
	</div>
	<!-- Page info end -->